package com.espark.adarsh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootOauth2ResourceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

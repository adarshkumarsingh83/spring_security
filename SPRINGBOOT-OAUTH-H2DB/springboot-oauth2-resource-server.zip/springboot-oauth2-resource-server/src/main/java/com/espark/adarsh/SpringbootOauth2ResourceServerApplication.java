package com.espark.adarsh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootOauth2ResourceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootOauth2ResourceServerApplication.class, args);
	}

}
